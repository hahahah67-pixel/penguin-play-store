#!/usr/bin/env bash
#
# install.sh — installs "Play Store" into the Crostini Linux container.
#
# This installs the app launcher only. Android SDK components themselves
# are downloaded by playstore.py the first time you click the app, so this
# script stays fast and small.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

INSTALL_BIN_DIR="$HOME/.local/bin"
INSTALL_SHARE_DIR="$HOME/.local/share/playstore-app"
DESKTOP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/256x256/apps"

echo "== Play Store installer =="

# ---------------------------------------------------------------------
# 1. System dependencies
# ---------------------------------------------------------------------
# - python3, python3-tk: the app itself and its GUI
# - openjdk-17-jre-headless: sdkmanager/avdmanager are Java tools and
#   require a JRE; 17 is the version Google's current command-line tools
#   documentation targets.
# - unzip, wget: used to fetch and extract the Android SDK Command-line
#   Tools the first time the app runs
# - qemu-kvm: on Chromebooks where nested virtualization is exposed to
#   Crostini, this ensures the KVM device node/tools exist so the
#   emulator's automatic hardware acceleration can be used. Harmless to
#   install even if this particular device/channel doesn't expose /dev/kvm.
echo "Installing required packages (you may be prompted for your password)..."
sudo apt-get update -y
sudo apt-get install -y \
    python3 \
    python3-tk \
    openjdk-17-jre-headless \
    unzip \
    wget \
    qemu-kvm || echo "Note: qemu-kvm package install failed or is unavailable on this system; continuing. The emulator will still run in software mode."

# ---------------------------------------------------------------------
# 2. Copy application files
# ---------------------------------------------------------------------
echo "Installing application files to $INSTALL_SHARE_DIR ..."
mkdir -p "$INSTALL_SHARE_DIR"
cp "$SCRIPT_DIR/playstore.py" "$INSTALL_SHARE_DIR/playstore.py"
chmod +x "$INSTALL_SHARE_DIR/playstore.py"

mkdir -p "$ICON_DIR"
cp "$SCRIPT_DIR/icons/playstore.png" "$ICON_DIR/playstore.png"

# A tiny wrapper on the PATH so the app can also be launched from a
# terminal by typing "playstore".
mkdir -p "$INSTALL_BIN_DIR"
cat > "$INSTALL_BIN_DIR/playstore" <<EOF
#!/usr/bin/env bash
exec python3 "$INSTALL_SHARE_DIR/playstore.py" "\$@"
EOF
chmod +x "$INSTALL_BIN_DIR/playstore"

# ---------------------------------------------------------------------
# 3. Desktop launcher entry (makes it show up in the Chromebook launcher)
# ---------------------------------------------------------------------
echo "Installing desktop launcher..."
mkdir -p "$DESKTOP_DIR"
sed \
    -e "s|__EXEC__|python3 $INSTALL_SHARE_DIR/playstore.py|g" \
    -e "s|__ICON__|$ICON_DIR/playstore.png|g" \
    "$SCRIPT_DIR/playstore.desktop" > "$DESKTOP_DIR/playstore.desktop"
chmod +x "$DESKTOP_DIR/playstore.desktop"

# Refresh the desktop database so the launcher shows up immediately, if
# the tool to do so is present (it is on most Crostini/Debian images).
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$DESKTOP_DIR" || true
fi

echo
echo "Done. Open the Chromebook launcher (search key) and search for 'Play Store'."
echo "The very first launch will download and set up the Android SDK and"
echo "Emulator automatically — this can take several minutes depending on"
echo "your internet connection. Every launch after that will be much faster."
