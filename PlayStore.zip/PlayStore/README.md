# Play Store

A one-click Android Emulator manager for Chromebooks that support **Linux
(Crostini)** but do **not** have native Android app support / the Google
Play Store built in.

This is **not** a hack of ChromeOS or ARC++/ARCVM. It automates Google's
own, officially documented developer tools — the Android SDK Command-line
Tools, `sdkmanager`, `avdmanager`, the Android Emulator, and `adb` — so
using them feels as close as possible to having a real Play Store app.

## What it does

**First launch:**
1. Downloads Google's official Android SDK Command-line Tools
2. Accepts the Android SDK license (required by Google's tooling)
3. Installs Platform Tools (`adb`) and the Android Emulator package
4. Installs a **Google Play–enabled** system image (`google_apis_playstore`)
5. Creates one persistent Android Virtual Device (AVD)
6. Boots it and waits for Android to finish starting
7. Opens Google Play automatically

**Every launch after that:**
1. Detects the existing installation (nothing is re-downloaded)
2. Boots the same AVD
3. Opens Google Play

Because the same AVD is reused every time, installed apps, sign-in state,
settings, game saves, downloads, and internal storage all persist, exactly
like a real phone.

## Requirements

- A Chromebook with Linux (Crostini) enabled
- Enough free disk space for the Android SDK, an emulator system image,
  and app data (several GB)
- An internet connection for the first launch

## Installing

```bash
git clone <this-repo>
cd PlayStore
chmod +x install.sh
./install.sh
```

Then open the Chromebook launcher (search/launcher key) and search for
**Play Store**.

## Project layout

```
PlayStore/
├── playstore.py       # all application logic (GUI + SDK/emulator automation)
├── install.sh          # installs dependencies + desktop launcher
├── playstore.desktop   # launcher entry template
├── README.md
└── icons/
    └── playstore.png
```

Everything the app installs (SDK, AVD, config, logs) lives under
`~/.local/share/playstore/` inside your Linux container, separate from the
app's own code in `~/.local/share/playstore-app/`.

## Honest limitations

- **Hardware acceleration is not guaranteed on every Chromebook.** Google
  documents that nested virtualization (which the emulator needs for fast,
  KVM-accelerated performance) is only exposed on *some* ChromeOS
  devices/boards/channels — not all. Play Store checks for `/dev/kvm` and
  warns you if it's unavailable, but the emulator will still run in
  software mode; it will just be noticeably slower. There is no supported
  way to force nested virtualization on a board that doesn't expose it.
- **This uses the official Android Emulator, not ARC++/ARCVM.** It cannot
  and does not try to replicate the exact performance or integration of a
  Chromebook's native Play Store — that subsystem is closed-source and not
  something third-party tools can legally or technically hook into. This
  project is the closest officially supported alternative.
- **Google Play sign-in and CTS behavior follow the emulator's own rules.**
  Play-enabled system images are signed with a release key on purpose
  (per Google's documentation), so root access isn't available on them —
  this is intentional and matches how a real, CTS-compliant device behaves.
- Architecture is auto-detected (`x86_64` or `arm64-v8a`) and the matching
  system image is installed automatically; there is no manual step.

## Uninstalling

```bash
rm -rf ~/.local/share/playstore ~/.local/share/playstore-app
rm -f ~/.local/share/applications/playstore.desktop
rm -f ~/.local/bin/playstore
```

## Running in GitHub Codespaces (web version, port 8000)

Codespaces is a very different environment from a Chromebook:

- It has **no display at all**, so there's nothing for the desktop app's
  window (or even the emulator's own window) to draw into.
- Codespaces containers almost certainly do **not** expose `/dev/kvm`.
  They run on the same underlying Azure VM infrastructure as GitHub's
  hosted Actions runners, which GitHub's and Google's own CI documentation
  confirm do not support nested virtualization. That means the emulator
  cannot use hardware acceleration here — it falls back to software CPU
  emulation and software (Swiftshader) GPU rendering, which is **much**
  slower to boot and noticeably laggier to use than on a real Chromebook
  with KVM available. This is a hard limit of Codespaces, not a bug in
  this project.

To work around the missing display, the Codespaces variant runs the
emulator against a virtual framebuffer (Xvfb) and streams that screen to
your browser over noVNC, on port **8000**. Everything else — SDK install,
AVD creation/reuse, boot detection, opening Google Play — reuses the exact
same code in `playstore.py` as the desktop app.

**To use it:**
1. Push this repository to GitHub with the `.devcontainer/` folder at the
   repo root (as included in this project).
2. Open the repo → **Code → Codespaces → Create codespace**.
3. Wait for the container to build, then for the "Play Store" port 8000
   popup/notification, or open it manually from the **Ports** tab.
4. The first load will take a while — it's doing the same SDK/AVD/boot
   process as the desktop app's first launch, just slower without
   acceleration. Subsequent codespace restarts reuse the same AVD, so they
   skip the SDK download/install (the AVD's app data persists for the
   life of the codespace, but is lost if the codespace is deleted).

### Files added for this variant
```
.devcontainer/
├── devcontainer.json    # builds the container, forwards port 8000
├── Dockerfile            # Java, Xvfb, x11vnc, noVNC, websockify
├── start.sh              # launches everything in the background
└── novnc-index.html      # auto-connecting noVNC landing page
codespaces/
└── playstore_web.py       # headless orchestration; imports playstore.py
```

