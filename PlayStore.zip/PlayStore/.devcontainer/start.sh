#!/usr/bin/env bash
# Entry point for the Codespaces/web variant of Play Store.
# Runs in the background so `postAttachCommand` doesn't block the terminal.

set -euo pipefail

WORKSPACE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

nohup python3 "$WORKSPACE_DIR/codespaces/playstore_web.py" \
    > "$WORKSPACE_DIR/.devcontainer/playstore-web.log" 2>&1 &

echo "Play Store is starting in the background."
echo "Log: $WORKSPACE_DIR/.devcontainer/playstore-web.log"
echo "Once you see a URL printed in that log (or the port 8000 popup"
echo "appears), open it to view and use Android in your browser."
