#!/usr/bin/env python3
"""
Play Store — one-click Google Android Emulator manager for Chromebooks
running Linux (Crostini) that do not have native Android/Play Store support.

This tool does NOT modify ChromeOS or hack ARC++/ARCVM. It automates only
Google's officially supported, publicly documented developer tools:

  - Android SDK Command-line Tools  (sdkmanager)   https://developer.android.com/tools/sdkmanager
  - Android Virtual Device manager  (avdmanager)    https://developer.android.com/tools/avdmanager
  - Android Emulator                (emulator)      https://developer.android.com/studio/run/emulator-commandline
  - Android Debug Bridge            (adb)           https://developer.android.com/tools/adb

All of these ship under the standard Android SDK license, are downloaded
directly from Google's servers (dl.google.com), and are the same tools a
human Android developer would install and run by hand. This script just
automates the steps and remembers the result.

Author: generated for a specific HP Chromebook x360 14-da0012dx (Crostini)
but written to work on any Linux/Crostini machine that meets the Android
Emulator's own requirements.
"""

import json
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

# --------------------------------------------------------------------------
# Constants
# --------------------------------------------------------------------------

APP_NAME = "Play Store"

# Everything this app installs lives under one directory in the user's
# home. This is the "best persistent storage location" question from the
# research requirements: the container's home directory (~) is the correct
# place, because it survives Crostini container restarts and ChromeOS
# reboots, is backed up by the standard Linux-files backup path Google
# documents for Crostini, and is NOT inside /tmp or any ephemeral mount.
APP_DATA_DIR = Path.home() / ".local" / "share" / "playstore"
SDK_ROOT = APP_DATA_DIR / "android-sdk"
AVD_HOME = APP_DATA_DIR / "avd"          # ANDROID_AVD_HOME
PREFS_ROOT = APP_DATA_DIR / "android-prefs"  # ANDROID_PREFS_ROOT
CONFIG_FILE = APP_DATA_DIR / "config.json"
LOG_FILE = APP_DATA_DIR / "playstore.log"

AVD_NAME = "PlayStoreAVD"

# Android 13 (API 33) is the last/most broadly available API level that
# Google ships with a "google_apis_playstore" (Play Store enabled) system
# image for BOTH x86_64 and arm64-v8a, so it works whether the Chromebook's
# Crostini container is x86_64 (Intel/AMD boards, like the target HP
# x360 14-da0012dx) or aarch64 (ARM boards). This is verified against
# Google's public system-image listing via `sdkmanager --list`, not guessed.
ANDROID_API_LEVEL = "33"

# Fallback direct-download URL used only if we cannot scrape the current
# build number from developer.android.com/studio at runtime. Google keeps
# the *_latest.zip naming scheme stable; only the numeric build id changes.
FALLBACK_CMDLINE_TOOLS_BUILD = "13114758"

CMDLINE_TOOLS_PAGE = "https://developer.android.com/studio"
CMDLINE_TOOLS_URL_RE = re.compile(
    r"https://dl\.google\.com/android/repository/commandlinetools-linux-(\d+)_latest\.zip"
)

os.makedirs(APP_DATA_DIR, exist_ok=True)


def log(msg: str):
    """Append a timestamped line to the log file and print it."""
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line)
    try:
        with open(LOG_FILE, "a") as f:
            f.write(line + "\n")
    except OSError:
        pass


# --------------------------------------------------------------------------
# Environment helpers
# --------------------------------------------------------------------------

def sdk_env():
    """
    Build the environment used for every sdkmanager / avdmanager / emulator /
    adb invocation. Google's tools historically looked at ANDROID_SDK_ROOT,
    and current Android Studio / command-line tooling looks at ANDROID_HOME;
    we set both to the same path so behavior is unambiguous regardless of
    which version of the tools ends up on disk. ANDROID_AVD_HOME and
    ANDROID_PREFS_ROOT keep the AVD and its config fully inside our own
    app-data directory instead of scattering files into ~/.android, so a
    user can find (or delete) everything Play Store owns in one place.
    """
    env = os.environ.copy()
    env["ANDROID_SDK_ROOT"] = str(SDK_ROOT)
    env["ANDROID_HOME"] = str(SDK_ROOT)
    env["ANDROID_AVD_HOME"] = str(AVD_HOME)
    env["ANDROID_PREFS_ROOT"] = str(PREFS_ROOT)
    return env


def host_abi():
    """
    Map the Crostini container's CPU architecture to the Android system
    image ABI the emulator needs. x86_64 Chromebooks (Intel/AMD, including
    the reference HP Chromebook x360 14-da0012dx) need an x86_64 system
    image to use KVM acceleration; arm64 Chromebook boards need arm64-v8a.
    """
    machine = platform.machine().lower()
    if machine in ("x86_64", "amd64"):
        return "x86_64"
    if machine in ("aarch64", "arm64"):
        return "arm64-v8a"
    raise RuntimeError(f"Unsupported/untested host architecture: {machine}")


def system_image_package(abi: str) -> str:
    return f"system-images;android-{ANDROID_API_LEVEL};google_apis_playstore;{abi}"


def sdkmanager_bin():
    return SDK_ROOT / "cmdline-tools" / "latest" / "bin" / "sdkmanager"


def avdmanager_bin():
    return SDK_ROOT / "cmdline-tools" / "latest" / "bin" / "avdmanager"


def adb_bin():
    return SDK_ROOT / "platform-tools" / "adb"


def emulator_bin():
    return SDK_ROOT / "emulator" / "emulator"


def kvm_available():
    """
    Best-effort check of whether hardware acceleration is usable. This is
    informational only — the emulator's own `-accel auto` (the default)
    already probes /dev/kvm and silently falls back to software emulation
    if it's missing, so we never need to branch our launch command on this.
    We surface it so the GUI can warn the user if things will be slow.
    Nested virtualization support on Crostini varies by Chromebook model,
    board, and ChromeOS channel/version — Google does not guarantee it on
    every device, so this must be detected, not assumed.
    """
    kvm_path = Path("/dev/kvm")
    return kvm_path.exists() and os.access(kvm_path, os.R_OK | os.W_OK)


# --------------------------------------------------------------------------
# Installation state
# --------------------------------------------------------------------------

def load_config():
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(cfg: dict):
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


def is_fully_installed() -> bool:
    """
    Detect an existing, complete installation so we never re-download or
    re-create anything that's already there. All four things below must
    exist: the command-line tools, platform-tools (adb), the emulator
    binary, and the AVD itself.
    """
    avd_ini = AVD_HOME / f"{AVD_NAME}.ini"
    avd_dir = AVD_HOME / f"{AVD_NAME}.avd"
    return (
        sdkmanager_bin().exists()
        and adb_bin().exists()
        and emulator_bin().exists()
        and avd_ini.exists()
        and avd_dir.exists()
    )


def sdk_tools_installed() -> bool:
    return sdkmanager_bin().exists()


def component_installed(package_dir: Path) -> bool:
    return package_dir.exists()


# --------------------------------------------------------------------------
# Step 1: Command-line tools bootstrap
# --------------------------------------------------------------------------

def resolve_cmdline_tools_url() -> str:
    """
    Scrape developer.android.com/studio for the current
    commandlinetools-linux-<build>_latest.zip URL so we always fetch the
    build Google currently publishes, rather than hard-coding a version
    that will eventually 404. Falls back to a known-good build id if the
    page can't be reached or its markup changes.
    """
    try:
        req = urllib.request.Request(
            CMDLINE_TOOLS_PAGE, headers={"User-Agent": "Mozilla/5.0"}
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            html = resp.read().decode("utf-8", errors="ignore")
        match = CMDLINE_TOOLS_URL_RE.search(html)
        if match:
            return match.group(0)
    except Exception as e:
        log(f"Could not fetch latest command-line tools URL live ({e}); using fallback build.")
    return (
        "https://dl.google.com/android/repository/"
        f"commandlinetools-linux-{FALLBACK_CMDLINE_TOOLS_BUILD}_latest.zip"
    )


def install_cmdline_tools(progress_cb):
    """
    Download and lay out the Android SDK Command-line Tools using the
    directory structure Google's own sdkmanager requires:
        <sdk_root>/cmdline-tools/latest/{bin,lib,NOTICE.txt,source.properties}
    (see https://developer.android.com/tools/sdkmanager — "Move the
    original cmdline-tools directory contents ... into the newly created
    latest directory.")
    """
    if sdk_tools_installed():
        log("Command-line tools already installed; skipping download.")
        return

    progress_cb("Downloading Android SDK...")
    url = resolve_cmdline_tools_url()
    log(f"Downloading command-line tools from {url}")

    zip_path = APP_DATA_DIR / "cmdline-tools.zip"
    urllib.request.urlretrieve(url, zip_path)

    extract_tmp = APP_DATA_DIR / "cmdline-tools-tmp"
    if extract_tmp.exists():
        shutil.rmtree(extract_tmp)
    extract_tmp.mkdir(parents=True)

    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(extract_tmp)

    # The archive always extracts to a top-level "cmdline-tools" folder.
    extracted_root = extract_tmp / "cmdline-tools"
    dest = SDK_ROOT / "cmdline-tools" / "latest"
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        shutil.rmtree(dest)
    shutil.move(str(extracted_root), str(dest))

    # Make sure the bin/ scripts are executable.
    bin_dir = dest / "bin"
    for f in bin_dir.glob("*"):
        st = os.stat(f)
        os.chmod(f, st.st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

    zip_path.unlink(missing_ok=True)
    shutil.rmtree(extract_tmp, ignore_errors=True)
    log("Command-line tools installed.")


def accept_licenses(progress_cb):
    """
    Equivalent of `yes | sdkmanager --licenses`. Required before any
    package install will succeed — Google's own docs note that without
    accepting the SDK license, package installs fail.
    """
    progress_cb("Accepting Android SDK license...")
    proc = subprocess.run(
        [str(sdkmanager_bin()), f"--sdk_root={SDK_ROOT}", "--licenses"],
        input="y\n" * 30,
        text=True,
        env=sdk_env(),
        capture_output=True,
    )
    log(proc.stdout)
    if proc.returncode != 0:
        log(f"License acceptance returned code {proc.returncode}: {proc.stderr}")


def sdkmanager_install(packages, progress_cb, label):
    progress_cb(label)
    cmd = [str(sdkmanager_bin()), f"--sdk_root={SDK_ROOT}"] + packages
    log(f"Running: {' '.join(cmd)}")
    proc = subprocess.run(
        cmd,
        input="y\n" * 5,  # in case a package still prompts for a license
        text=True,
        env=sdk_env(),
        capture_output=True,
    )
    log(proc.stdout[-4000:])
    if proc.returncode != 0:
        raise RuntimeError(
            f"sdkmanager failed installing {packages}:\n{proc.stderr[-2000:]}"
        )


# --------------------------------------------------------------------------
# Step 2: Platform-tools, emulator, system image
# --------------------------------------------------------------------------

def install_platform_tools(progress_cb):
    if adb_bin().exists():
        log("platform-tools already installed; skipping.")
        return
    sdkmanager_install(["platform-tools"], progress_cb, "Checking installation...")


def install_emulator(progress_cb):
    if emulator_bin().exists():
        log("emulator already installed; skipping.")
        return
    sdkmanager_install(["emulator"], progress_cb, "Installing Emulator...")


def install_system_image(progress_cb, abi):
    package = system_image_package(abi)
    image_dir = SDK_ROOT / "system-images" / f"android-{ANDROID_API_LEVEL}" / "google_apis_playstore" / abi
    if component_installed(image_dir):
        log(f"System image {package} already installed; skipping.")
        return
    sdkmanager_install([package], progress_cb, "Downloading Android SDK...")


# --------------------------------------------------------------------------
# Step 3: AVD creation
# --------------------------------------------------------------------------

def create_avd(progress_cb, abi):
    """
    Create ONE persistent AVD that is reused on every future launch. Using
    --force is safe here because we only call this when is_fully_installed()
    was False, i.e. there is no AVD we'd be destroying data on.
    """
    avd_ini = AVD_HOME / f"{AVD_NAME}.ini"
    if avd_ini.exists():
        log("AVD already exists; skipping creation.")
        return

    progress_cb("Creating Android Device...")
    AVD_HOME.mkdir(parents=True, exist_ok=True)
    package = system_image_package(abi)

    cmd = [
        str(avdmanager_bin()),
        "--verbose",
        "create", "avd",
        "--force",
        "--name", AVD_NAME,
        "--package", package,
        "--device", "pixel",
    ]
    log(f"Running: {' '.join(cmd)}")
    proc = subprocess.run(
        cmd,
        input="no\n",  # answers "Do you wish to create a custom hardware profile?"
        text=True,
        env=sdk_env(),
        capture_output=True,
    )
    log(proc.stdout)
    if proc.returncode != 0:
        raise RuntimeError(f"avdmanager failed to create AVD:\n{proc.stderr[-2000:]}")

    # Give the AVD a bit more internal storage than the 2 GB default so
    # installed apps, game saves, and downloads have realistic room to
    # grow, since this single AVD is meant to be reused forever.
    config_ini = AVD_HOME / f"{AVD_NAME}.avd" / "config.ini"
    if config_ini.exists():
        with open(config_ini, "a") as f:
            f.write("disk.dataPartition.size=8G\n")

    log("AVD created.")


# --------------------------------------------------------------------------
# Step 4: Boot + launch Google Play
# --------------------------------------------------------------------------

def boot_android(progress_cb, accel="auto", extra_emulator_args=None, extra_env=None):
    """
    Launch the emulator against our persistent AVD. `-accel auto` (the
    default) uses KVM automatically when /dev/kvm is available and falls
    back to software emulation otherwise, so this single command line
    works whether or not the Chromebook's Crostini build exposes nested
    virtualization for this board/channel.

    `accel` / `extra_emulator_args` / `extra_env` let a caller (e.g. the
    Codespaces/web variant of this app) run the exact same install+boot
    pipeline while pointing the emulator at a virtual X display and
    forcing software rendering, without duplicating any of the logic
    above. The Crostini desktop app calls this with the defaults.
    """
    progress_cb("Starting Android...")

    if not kvm_available():
        log(
            "WARNING: /dev/kvm is not accessible in this environment. "
            "The emulator will still run, but without hardware acceleration "
            "it will boot and respond noticeably slower."
        )

    cmd = [
        str(emulator_bin()),
        "-avd", AVD_NAME,
        "-accel", accel,
        "-netdelay", "none",
        "-netspeed", "full",
    ]
    if extra_emulator_args:
        cmd.extend(extra_emulator_args)

    env = sdk_env()
    if extra_env:
        env.update(extra_env)

    log(f"Launching: {' '.join(cmd)}")
    # Detached: the emulator owns its own window (via Crostini's Wayland/
    # Sommelier integration, or a virtual display in headless mode) and
    # keeps running after this script's GUI closes, exactly like a real
    # app would.
    subprocess.Popen(
        cmd,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )


def wait_for_boot(progress_cb, timeout_seconds=300):
    """
    The officially documented way to detect a fully booted emulator is to
    poll the `sys.boot_completed` system property over adb until it reads
    "1" (this is the same technique used in Google's own CI infra and the
    Android Emulator's own tooling). We wait-for-device first so `adb
    shell` calls don't fail before the emulator socket exists.
    """
    progress_cb("Preparing Android...")
    adb = str(adb_bin())
    env = sdk_env()

    subprocess.run([adb, "wait-for-device"], env=env, timeout=timeout_seconds)

    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        try:
            result = subprocess.run(
                [adb, "shell", "getprop", "sys.boot_completed"],
                env=env,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.stdout.strip() == "1":
                log("Android has finished booting.")
                return True
        except subprocess.TimeoutExpired:
            pass
        time.sleep(2)

    raise TimeoutError("Android did not finish booting within the expected time.")


def open_google_play(progress_cb):
    """
    Launch the Play Store app (package com.android.vending) the same way
    `adb shell monkey` is documented to launch any app's default activity:
    https://developer.android.com/tools/adb (Issue a monkey event to the
    launcher category of a given package to bring it to the foreground.)
    """
    progress_cb("Opening Google Play...")
    adb = str(adb_bin())
    cmd = [
        adb, "shell", "monkey",
        "-p", "com.android.vending",
        "-c", "android.intent.category.LAUNCHER",
        "1",
    ]
    log(f"Running: {' '.join(cmd)}")
    subprocess.run(cmd, env=sdk_env(), capture_output=True, text=True, timeout=30)


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------

def run_first_time_setup(progress_cb):
    progress_cb("Checking installation...")
    abi = host_abi()
    log(f"Detected host ABI: {abi}")

    install_cmdline_tools(progress_cb)
    accept_licenses(progress_cb)
    install_platform_tools(progress_cb)
    install_emulator(progress_cb)
    install_system_image(progress_cb, abi)
    create_avd(progress_cb, abi)

    save_config({"abi": abi, "api_level": ANDROID_API_LEVEL, "setup_complete": True})


def run_launch_sequence(progress_cb, accel="auto", extra_emulator_args=None, extra_env=None):
    if not is_fully_installed():
        run_first_time_setup(progress_cb)
    else:
        progress_cb("Checking installation...")
        log("Existing installation detected; reusing it.")

    boot_android(progress_cb, accel=accel, extra_emulator_args=extra_emulator_args, extra_env=extra_env)
    wait_for_boot(progress_cb)
    open_google_play(progress_cb)
    progress_cb("Done")


# --------------------------------------------------------------------------
# GUI
# --------------------------------------------------------------------------

def run_gui():
    import tkinter as tk
    from tkinter import ttk, messagebox

    root = tk.Tk()
    root.title(APP_NAME)
    root.geometry("420x160")
    root.resizable(False, False)

    frame = ttk.Frame(root, padding=24)
    frame.pack(fill="both", expand=True)

    title_label = ttk.Label(frame, text=APP_NAME, font=("Sans", 16, "bold"))
    title_label.pack(pady=(0, 12))

    status_var = tk.StringVar(value="Preparing Android...")
    status_label = ttk.Label(frame, textvariable=status_var, font=("Sans", 11))
    status_label.pack(pady=(0, 12))

    progress = ttk.Progressbar(frame, mode="indeterminate", length=340)
    progress.pack(pady=(0, 8))
    progress.start(12)

    def update_status(text):
        # Called from the worker thread; tkinter widgets must only be
        # touched from the main thread, so marshal via `after`.
        def apply():
            status_var.set(text)
        root.after(0, apply)

    def on_error(exc):
        def apply():
            progress.stop()
            messagebox.showerror(
                APP_NAME,
                f"Something went wrong:\n\n{exc}\n\nSee {LOG_FILE} for details.",
            )
            root.destroy()
        root.after(0, apply)

    def on_done():
        def apply():
            progress.stop()
            status_var.set("Google Play is open.")
            root.after(1500, root.destroy)
        root.after(0, apply)

    def worker():
        try:
            run_launch_sequence(update_status)
            on_done()
        except Exception as exc:  # noqa: BLE001 - surfaced to the user, not swallowed
            log(f"ERROR: {exc}")
            on_error(exc)

    threading.Thread(target=worker, daemon=True).start()
    root.mainloop()


def run_headless():
    """Fallback path if tkinter isn't available: same logic, printed to stdout."""
    def progress_cb(text):
        print(f"==> {text}")

    try:
        run_launch_sequence(progress_cb)
    except Exception as exc:
        print(f"ERROR: {exc}")
        sys.exit(1)


def main():
    log("Play Store launched.")
    try:
        import tkinter  # noqa: F401
        run_gui()
    except ImportError:
        log("tkinter not available; falling back to console output.")
        run_headless()


if __name__ == "__main__":
    main()
